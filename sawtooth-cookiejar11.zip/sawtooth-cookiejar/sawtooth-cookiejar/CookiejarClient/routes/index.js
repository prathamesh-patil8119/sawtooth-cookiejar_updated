var express = require('express');
var router = express.Router();
var { CookiejarClient } = require('./CookiejarClient');
// var fs = require('fs');


/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'KBA' });
});

router.get('/bake', function (req, res) {
  res.render('Bake');
});

router.get('/eat', function (req, res) {
  res.render('Eat');
});

router.get('/count', function (req, res) {
  res.render('Count');
});

router.get('/home', function (req, res) {
  res.render('Home', { title: 'Sawtooth' });
});

router.post('/', function (req, res) {
  var Key = req.body.privateKey;
  var cookiejar_client = new CookiejarClient(Key);  //?
  res.send({ done: 1, privatekey: Key, message: "Your private key is " + Key });
});


router.post('/bake', function (req, res) {
  var count = req.body.cookie;
  var pri_key = req.body.pri_key;
  var cookiejar_client = new CookiejarClient(pri_key);
  var action = "bake";
  cookiejar_client.send_data(action, count);
  res.send({ message: "Bake " + count + " cookies request sent" });
});

router.post('/eat', function (req, res) {
  var count = req.body.cookie;
  var pri_key = req.body.pri_key;
  var c = req.body.Count;
  var cookiejar_client = new CookiejarClient(pri_key, c);
  var action = "eat";
  // cookiejar_client.send_data(action, count);
  console.log("eat object : " + JSON.stringify(cookiejar_client));
  cookiejar_client.send_data(action, c, JSON.stringify(count));
  res.send({ message: "Eat " + JSON.stringify(count) + " cookies request sent" });
});

router.post('/count', function (req, res) {
  var pri_key = req.body.pri_key;
  const cookiejar_client = new CookiejarClient(pri_key);
  const cookieCount = cookiejar_client._get_cookie_count();
  console.log("object count : " + JSON.stringify(cookieCount));
  // res.send({message:"............... "+ });
  cookieCount.then(function (result) {
var alldata=[];
    console.log("result :" + result);


    var listd = [];

    var objectlist = [];
    //var r=result.split("\":\"");

    var objl = result.split("}");

    for (var i = 0; i < objl.length; i++) {
      objectlist[objectlist.length] = objl[i];
    }


    console.log("objectlist data" + objectlist[1]);

    for (var j = 0; j < objectlist.length-1; j++) {
      var r=objectlist[j].split(/[\":\",\"\,\"]/);
      for (var i = 1; i < r.length; i++) {
        if (i % 2 == 0 && r[i] != ""&& r[i]!="{") {
          listd[listd.length] = r[i];
          //  console.log("data"+listd[i]+" i : "+i+"\n");
        }
      }

      var data = {
        "FIRST_NAME": listd[0],
        "SECOND_NAME": listd[1],
        "CONTACT_NUMBER": listd[2],
        "ADDHAR_NUMBER": listd[3],
        "STATE": listd[4],
        "DISTRICT": listd[5],
      };
      listd=[];
      alldata[alldata.length]=data;
    }

    console.log("\nlist data " + JSON.stringify(alldata));
    //var re=JSON.stringify(r);
    // console.log("result :"+result+"listd : "+listd);
   

    console.log(data.FIRST_NAME + " DATA: " + JSON.stringify(data));
    res.send({ count: alldata });
  });

  // cookieCount.then(res.send({ count: cookieCount }));
})
module.exports = router;

var express = require('express');
var router = express.Router();
var { CookiejarClient } = require('./CookiejarClient');
// var fs = require('fs');


/* GET home page. */

router.get('/', function (req, res, next) {
  res.render('index', { title: 'KBA' });
});

router.get('/register_farm', function (req, res) {
  res.render('regFarm');
});

router.post('/register', function (req, res) {
  
  console.log("inside index js");
  var first_name = req.body.first_name;
  var last_name = req.body.last_name;
  var contact_number = req.body.contact_number;
  var aadhar_number = req.body.aadhar_number;
  var farmer_state = req.body.farmer_state;
  var farmer_district = req.body.farmer_district;

  console.log("",first_name);

  var cookiejar_client = new CookiejarClient(pri_key);
 console.log("line 1");
  var action = "register";
 console.log("line 2");
  cookiejar_client.send_data(action, first_name, last_name, contact_number, aadhar_number, farmer_state, farmer_district);
 console.log("line 3");
  res.send({ message: "Registeration Request send " });
});

router.get('/bake', function (req, res) {
  res.render('Bake');
});

router.get('/eat', function (req, res) {
  res.render('Eat');
});

router.get('/count', function (req, res) {
  res.render('Count');
});

router.get('/home', function (req, res) {
  res.render('Home', { title: 'Sawtooth' });
});

router.post('/', function (req, res) {
  var Key = req.body.privateKey;
  var cookiejar_client = new CookiejarClient(Key);  //?
  res.send({ done: 1, privatekey: Key, message: "Your private key is " + Key });
});


router.post('/bake', function (req, res) {
  var count = req.body.cookie;
  var pri_key = req.body.pri_key;
  var cookiejar_client = new CookiejarClient(pri_key);
  var action = "bake";
  cookiejar_client.send_data(action, count);
  res.send({ message: "Bake " + count + " cookies request sent" });
});

router.post('/eat', function (req, res) {
  var count = req.body.cookie;
  var pri_key = req.body.pri_key;
  var cookiejar_client = new CookiejarClient(pri_key);
  var action = "eat";
  cookiejar_client.send_data(action, count);
  res.send({ message: "Eat " + count + " cookies request sent" });
});

router.post('/count', function (req, res) {
  var pri_key = req.body.pri_key;
  const cookiejar_client = new CookiejarClient(pri_key);
  const cookieCount = cookiejar_client._get_cookie_count();
  cookieCount.then(function (result) { res.send({ count: result }); });
})

module.exports = router;
